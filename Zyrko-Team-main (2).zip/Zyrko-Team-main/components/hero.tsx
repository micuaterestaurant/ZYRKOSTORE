"use client"

import Image from "next/image"
import { ArrowDown } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">

      {/* BACKGROUND (más limpio estilo Apple) */}
      <div className="absolute inset-0 bg-black" />
      <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(circle_at_center,_white_1px,_transparent_1px)] bg-[length:40px_40px]" />

      {/* CONTENT */}
      <div className="container mx-auto px-4 lg:px-8 relative z-10 pt-28 pb-16">

        <div className="grid lg:grid-cols-2 gap-12 items-center">

          {/* TEXT */}
          <div className="text-center lg:text-left">

            <span className="inline-block text-xs tracking-[0.35em] text-white/50 uppercase mb-6">
              Drop 001 • Limited Edition
            </span>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-light leading-[0.9]">
              Nike Mind
              <br />
              <span className="font-semibold">001</span>
            </h1>

            <p className="mt-6 text-white/50 text-lg max-w-md mx-auto lg:mx-0 leading-relaxed">
              Minimal design. Maximum comfort. Built for everyday streetwear.
            </p>

            {/* CTA */}
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">

              <a
                href="https://wa.me/34643574361?text=Quiero%20las%20Nike%20Mind%20001"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white text-black px-8 py-4 rounded-full font-medium hover:scale-[1.02] transition"
              >
                Comprar ahora
              </a>

              <a
                href="#catalogo"
                className="border border-white/15 px-8 py-4 rounded-full text-white/80 hover:bg-white/5 transition"
              >
                Ver catálogo
              </a>

            </div>

            {/* TRUST */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 mt-10 text-xs text-white/40">
              <span>✔ Envíos internacionales</span>
              <span>✔ Pago seguro</span>
              <span>✔ Stock limitado</span>
            </div>

          </div>

          {/* IMAGE */}
          <div className="relative flex justify-center">

            <div className="relative w-full max-w-md aspect-square">

              {/* glow suave */}
              <div className="absolute inset-0 bg-white/5 blur-3xl scale-110 rounded-full" />

              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4a4a62f877ccbc7578eca847137e1a26.webp.jpg-xRhuQuXC8UbdXAJnvmvRvlaR4hjB3p.webp"
                alt="Nike Mind 001"
                fill
                priority
                className="object-contain drop-shadow-2xl"
              />

            </div>

            {/* PRICE TAG */}
            <div className="absolute bottom-4 right-4 bg-white/5 backdrop-blur-xl border border-white/10 px-5 py-3 rounded-2xl">
              <span className="text-xs text-white/40 block">FROM</span>
              <span className="text-xl font-semibold">62,99€</span>
            </div>

          </div>

        </div>
      </div>

      {/* SCROLL INDICATOR */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/30">
        <a href="#catalogo" className="flex flex-col items-center gap-1">
          <span className="text-xs tracking-widest">SCROLL</span>
          <ArrowDown className="w-4 h-4 animate-bounce" />
        </a>
      </div>

    </section>
  )
}
