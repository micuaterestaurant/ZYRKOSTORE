"use client"

import { useState } from "react"
import { faqs } from "@/lib/data"
import { ChevronDown, MessageCircle } from "lucide-react"

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section id="faq" className="py-20 lg:py-32 relative">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12 lg:mb-16">
            <span className="inline-block text-xs tracking-[0.3em] text-muted-foreground uppercase mb-4">
              Support
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground">
              Everything you need to know about ordering from ZYRKO STORE.
            </p>
          </div>

          {/* FAQ Items */}
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-card/50 rounded-2xl border border-border/50 overflow-hidden transition-all duration-300 hover:border-border"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <span className="font-semibold text-base lg:text-lg pr-4">
                    {faq.question}
                  </span>
                  <ChevronDown 
                    className={`w-5 h-5 flex-shrink-0 text-muted-foreground transition-transform duration-300 ${
                      openIndex === index ? "rotate-180" : ""
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? "max-h-96" : "max-h-0"
                  }`}
                >
                  <div className="px-6 pb-6 text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Contact CTA */}
          <div className="mt-12 lg:mt-16 text-center p-8 bg-card/50 rounded-3xl border border-border/50">
            <h3 className="text-xl font-semibold mb-2">Still have questions?</h3>
            <p className="text-muted-foreground mb-6">
              We&apos;re here to help. Contact us directly via WhatsApp.
            </p>
            <a
              href="https://wa.me/34643574361?text=Hola%20tengo%20una%20pregunta%20sobre%20ZYRKO"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-shine inline-flex items-center gap-2 bg-foreground text-background px-8 py-4 rounded-full font-medium tracking-wider hover:bg-foreground/90 transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              CHAT WITH US
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
