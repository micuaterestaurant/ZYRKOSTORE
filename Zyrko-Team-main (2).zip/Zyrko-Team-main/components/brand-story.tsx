import Image from "next/image"
import { products } from "@/lib/data"

export function BrandStory() {
  return (
    <section id="story" className="py-20 lg:py-32 relative overflow-hidden">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Text Content */}
          <div className="order-2 lg:order-1">
            <span className="inline-block text-xs tracking-[0.3em] text-muted-foreground uppercase mb-4">
              Our Story
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-6 leading-tight">
              Born from the streets.
              <br />
              <span className="text-gradient">Built for the world.</span>
            </h2>
            
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                ZYRKO was founded with a simple mission: to bring premium quality sneakers to 
                enthusiasts worldwide without the ridiculous markups. We believe that exceptional 
                footwear should be accessible to everyone who appreciates quality craftsmanship.
              </p>
              <p>
                Every pair in our collection is carefully curated and quality-checked. We work 
                directly with trusted suppliers to ensure authenticity and premium construction 
                that stands the test of time.
              </p>
              <p>
                From Madrid to the world — we ship to over 100 countries, bringing the best of 
                streetwear culture to your doorstep. Our limited drops ensure exclusivity while 
                our WhatsApp-first approach guarantees personal, fast service.
              </p>
            </div>

            {/* Founder Quote */}
            <div className="mt-8 p-6 bg-card/50 rounded-2xl border border-border/50">
              <p className="text-lg italic mb-4">
                &ldquo;We don&apos;t just sell sneakers. We curate experiences for those who live and breathe streetwear culture.&rdquo;
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-sm font-semibold">
                  Z
                </div>
                <div>
                  <span className="block text-sm font-medium">ZYRKO Team</span>
                  <span className="block text-xs text-muted-foreground">Founded 2024 • Madrid, Spain</span>
                </div>
              </div>
            </div>
          </div>

          {/* Image Grid */}
          <div className="order-1 lg:order-2 relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
                  <Image
                    src={products[0].image}
                    alt="ZYRKO Sneaker"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                </div>
                <div className="relative aspect-square rounded-2xl overflow-hidden">
                  <Image
                    src={products[3].image}
                    alt="ZYRKO Sneaker"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="relative aspect-square rounded-2xl overflow-hidden">
                  <Image
                    src={products[2].image}
                    alt="ZYRKO Sneaker"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                </div>
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
                  <Image
                    src={products[4].image}
                    alt="ZYRKO Sneaker"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-4 -left-4 glass px-5 py-3 rounded-2xl">
              <span className="text-xs text-muted-foreground tracking-wider block">SHIPPED TO</span>
              <span className="text-xl font-bold">100+ Countries</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
