import Image from "next/image"
import { products } from "@/lib/data"
import { Instagram } from "lucide-react"

const galleryImages = [
  products[0].image,
  products[1].image,
  products[2].image,
  products[3].image,
  products[4].image,
  products[5].image,
]

export function InstagramGallery() {
  return (
    <section className="py-20 lg:py-32 relative overflow-hidden">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12 lg:mb-16">
          <span className="inline-block text-xs tracking-[0.3em] text-muted-foreground uppercase mb-4">
            @zyrkostore
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
            Follow the Culture
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Join our community on Instagram for exclusive drops, behind-the-scenes content, and streetwear inspiration.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 lg:gap-3">
          {galleryImages.map((image, index) => (
            <a
              key={index}
              href="https://instagram.com/zyrkostore"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative aspect-square rounded-xl lg:rounded-2xl overflow-hidden"
            >
              <Image
                src={image}
                alt={`ZYRKO Instagram gallery ${index + 1}`}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110"
                sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 16vw"
              />
              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <Instagram className="w-8 h-8 text-white" />
              </div>
            </a>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-10 lg:mt-12">
          <a
            href="https://instagram.com/zyrkostore"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 border border-border rounded-full hover:bg-secondary transition-colors"
          >
            <Instagram className="w-5 h-5" />
            <span className="font-medium tracking-wider text-sm">FOLLOW @ZYRKOSTORE</span>
          </a>
        </div>
      </div>
    </section>
  )
}
