"use client"

import { useState } from "react"
import { reviews } from "@/lib/data"
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react"

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < rating ? "fill-foreground text-foreground" : "text-muted-foreground/30"
          }`}
        />
      ))}
    </div>
  )
}

export function CustomerReviews() {
  const [activeIndex, setActiveIndex] = useState(0)
  const visibleReviews = 3

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % (reviews.length - visibleReviews + 1))
  }

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + (reviews.length - visibleReviews + 1)) % (reviews.length - visibleReviews + 1))
  }

  return (
    <section className="py-20 lg:py-32 bg-card/30 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />

      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-12 lg:mb-16">
          <div>
            <span className="inline-block text-xs tracking-[0.3em] text-muted-foreground uppercase mb-4">
              Testimonials
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
              What Our Customers Say
            </h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={prevSlide}
              disabled={activeIndex === 0}
              className="w-12 h-12 rounded-full border border-border flex items-center justify-center hover:bg-secondary transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              aria-label="Previous review"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={nextSlide}
              disabled={activeIndex >= reviews.length - visibleReviews}
              className="w-12 h-12 rounded-full border border-border flex items-center justify-center hover:bg-secondary transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              aria-label="Next review"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reviews Slider - Mobile */}
        <div className="lg:hidden overflow-x-auto scrollbar-hide -mx-4 px-4">
          <div className="flex gap-4" style={{ width: `${reviews.length * 85}%` }}>
            {reviews.map((review) => (
              <div
                key={review.id}
                className="flex-shrink-0 w-[85%] bg-card rounded-2xl p-6 border border-border/50"
              >
                <Quote className="w-8 h-8 text-muted-foreground/20 mb-4" />
                <StarRating rating={review.rating} />
                <p className="mt-4 mb-6 text-foreground leading-relaxed">
                  &ldquo;{review.text}&rdquo;
                </p>
                <div className="flex items-center justify-between pt-4 border-t border-border/50">
                  <div>
                    <p className="font-medium text-sm">{review.name}</p>
                    <p className="text-xs text-muted-foreground">{review.location}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">{review.product}</p>
                    {review.verified && (
                      <span className="inline-flex items-center gap-1 text-[10px] text-green-500 mt-1">
                        <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                        Verified Purchase
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews Grid - Desktop */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-6 overflow-hidden">
          {reviews.slice(activeIndex, activeIndex + visibleReviews).map((review, index) => (
            <div
              key={review.id}
              className="bg-card rounded-2xl p-8 border border-border/50 transition-all duration-300"
              style={{ 
                animationDelay: `${index * 100}ms`,
                opacity: 1
              }}
            >
              <Quote className="w-10 h-10 text-muted-foreground/20 mb-6" />
              <StarRating rating={review.rating} />
              <p className="mt-6 mb-8 text-lg text-foreground leading-relaxed">
                &ldquo;{review.text}&rdquo;
              </p>
              <div className="flex items-center justify-between pt-6 border-t border-border/50">
                <div>
                  <p className="font-semibold">{review.name}</p>
                  <p className="text-sm text-muted-foreground">{review.location}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">{review.product}</p>
                  {review.verified && (
                    <span className="inline-flex items-center gap-1 text-xs text-green-500 mt-1">
                      <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                      Verified
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Average Rating */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12 pt-12 border-t border-border/50">
          <div className="flex items-center gap-2">
            <span className="text-3xl font-bold">5.0</span>
            <StarRating rating={5} />
          </div>
          <span className="text-muted-foreground text-sm">
            Based on {reviews.length}+ verified customer reviews
          </span>
        </div>
      </div>
    </section>
  )
}
