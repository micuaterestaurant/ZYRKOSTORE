import { MessageCircle, ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 premium-gradient" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs tracking-wider">LIMITED STOCK AVAILABLE</span>
          </div>

          {/* Heading */}
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6 leading-tight">
            Ready to Elevate
            <br />
            <span className="text-gradient">Your Style?</span>
          </h2>

          {/* Description */}
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Join thousands of sneaker enthusiasts worldwide. Order now via WhatsApp for personalized service and exclusive access to limited drops.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="https://wa.me/34643574361?text=Hola%20quiero%20pedir%20unas%20ZYRKO"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-shine w-full sm:w-auto flex items-center justify-center gap-3 bg-foreground text-background px-10 py-5 rounded-full font-medium tracking-wider hover:bg-foreground/90 transition-all duration-300 text-base"
            >
              <MessageCircle className="w-5 h-5" />
              ORDER NOW ON WHATSAPP
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="#drop"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-10 py-5 border border-border rounded-full font-medium tracking-wider hover:bg-secondary transition-all duration-300 text-base"
            >
              VIEW COLLECTION
            </a>
          </div>

          {/* Trust indicators */}
          <div className="flex flex-wrap items-center justify-center gap-6 lg:gap-10 mt-12 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Free Shipping over 150€
            </span>
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              14-Day Returns
            </span>
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Worldwide Delivery
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
