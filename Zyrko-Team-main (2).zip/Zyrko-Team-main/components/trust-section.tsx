import { Globe, Shield, MessageCircle, Sparkles, CheckCircle } from "lucide-react"

const features = [
  {
    icon: Globe,
    title: "Worldwide Shipping",
    description: "We deliver to 100+ countries with full tracking on every order"
  },
  {
    icon: Shield,
    title: "Secure Orders",
    description: "Protected payments via WhatsApp verification for peace of mind"
  },
  {
    icon: MessageCircle,
    title: "Fast Support",
    description: "WhatsApp support responds within 2-4 hours on business days"
  },
  {
    icon: Sparkles,
    title: "Limited Stock",
    description: "Exclusive drops with limited quantities. When they are gone, they are gone"
  },
  {
    icon: CheckCircle,
    title: "Premium Quality",
    description: "Every pair is quality-checked before shipping to ensure perfection"
  }
]

export function TrustSection() {
  return (
    <section className="py-20 lg:py-28 border-y border-border/50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 lg:mb-16">
          <span className="inline-block text-xs tracking-[0.3em] text-muted-foreground uppercase mb-4">
            Why ZYRKO?
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
            Built on Trust
          </h2>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-4">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className="group p-6 lg:p-5 bg-card/50 rounded-2xl border border-border/50 hover:border-border transition-all duration-300 hover:bg-card"
            >
              <div 
                className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center mb-4 group-hover:bg-foreground group-hover:text-background transition-colors"
              >
                <feature.icon className="w-5 h-5" />
              </div>
              <h3 className="text-base font-semibold mb-2 tracking-tight">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mt-16 pt-16 border-t border-border/50">
          <div className="text-center">
            <span className="block text-3xl lg:text-4xl font-bold mb-1">100+</span>
            <span className="text-sm text-muted-foreground">Countries Shipped</span>
          </div>
          <div className="text-center">
            <span className="block text-3xl lg:text-4xl font-bold mb-1">2-4h</span>
            <span className="text-sm text-muted-foreground">Support Response</span>
          </div>
          <div className="text-center">
            <span className="block text-3xl lg:text-4xl font-bold mb-1">5★</span>
            <span className="text-sm text-muted-foreground">Average Rating</span>
          </div>
          <div className="text-center">
            <span className="block text-3xl lg:text-4xl font-bold mb-1">14d</span>
            <span className="text-sm text-muted-foreground">Easy Returns</span>
          </div>
        </div>
      </div>
    </section>
  )
}
