"use client"

import Image from "next/image"
import { useState } from "react"
import { products } from "@/lib/data"
import { MessageCircle, ChevronRight } from "lucide-react"

type Product = {
  id: number
  name: string
  price: string
  tag: string
  image: string
  description: string
  sizes?: string[]
}

function ProductCard({ product }: { product: Product }) {
  const [selectedSize, setSelectedSize] = useState<string | null>(null)

  if (!product || !product.image) return null

  const whatsappUrl = `https://wa.me/34643574361?text=${encodeURIComponent(
    `Hola! Quiero ${product.name}${selectedSize ? ` talla ${selectedSize}` : ""} (${product.price})`
  )}`

  return (
    <div className="product-card bg-card rounded-2xl overflow-hidden border border-white/10">

      <div className="relative aspect-square bg-black/20">

        <div className="absolute top-4 left-4 z-10">
          <span className="px-3 py-1 text-[10px] bg-white text-black rounded-full">
            {product.tag}
          </span>
        </div>

        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover"
        />
      </div>

      <div className="p-5">

        <div className="flex justify-between items-start">
          <h3 className="font-semibold text-lg">{product.name}</h3>
          <span className="font-bold">{product.price}</span>
        </div>

        <p className="text-sm text-white/60 mt-2">
          {product.description}
        </p>

        <div className="flex gap-2 flex-wrap mt-4">
          {product.sizes?.map((size) => (
            <button
              key={size}
              onClick={() => setSelectedSize(size)}
              className={`px-3 py-1 text-xs rounded border transition ${
                selectedSize === size
                  ? "bg-white text-black"
                  : "border-white/10 text-white/70"
              }`}
            >
              {size}
            </button>
          ))}
        </div>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-5 flex items-center justify-center gap-2 bg-white text-black py-3 rounded-xl text-sm font-medium hover:opacity-90 transition"
        >
          <MessageCircle className="w-4 h-4" />
          ORDER VIA WHATSAPP
          <ChevronRight className="w-4 h-4" />
        </a>

      </div>
    </div>
  )
}

export function FeaturedDrop() {
  return (
    <section id="drop" className="py-20">

      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold">DROP 001</h2>
        <p className="text-white/60 mt-2">
          Limited premium sneakers collection
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 px-4 lg:px-8">
        {products?.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>

      <div className="text-center mt-12 text-sm text-white/50">
        Need help? Contact us on WhatsApp
      </div>

    </section>
  )
}
