"use client"

import Link from "next/link"

export function Header() {
  return (
    <header className="fixed top-0 w-full z-50 bg-black/40 backdrop-blur border-b border-white/5">

      <div className="flex justify-between items-center px-6 py-4">

        <span className="tracking-[0.35em] font-bold">
          ZYRKO
        </span>

        <nav className="hidden md:flex gap-8 text-sm text-white/60">
          <Link href="#drop">SHOP</Link>
          <Link href="#faq">FAQ</Link>
        </nav>

        <a
          href="https://wa.me/34643574361"
          className="bg-white text-black px-5 py-2 rounded-full text-sm font-medium"
        >
          ORDER
        </a>

      </div>

    </header>
  )
}
