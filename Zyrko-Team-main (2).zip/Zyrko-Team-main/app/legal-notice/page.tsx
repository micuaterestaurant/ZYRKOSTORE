import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Legal Notice | ZYRKO STORE",
  description: "Legal notice and company information for ZYRKO STORE. Spain-based premium sneaker retailer.",
}

export default function LegalNotice() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50">
        <div className="container mx-auto px-4 lg:px-8 py-6">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Store
          </Link>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight mb-4">Legal Notice</h1>
          <p className="text-muted-foreground mb-8">Aviso Legal</p>

          <div className="prose prose-invert prose-gray max-w-none space-y-8">
            <section>
              <h2 className="text-xl font-semibold mb-4">1. Website Owner Information</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                In compliance with Law 34/2002, of July 11, on Information Society Services and Electronic Commerce (LSSI-CE), the following information is provided:
              </p>
              <ul className="list-none text-muted-foreground space-y-2">
                <li><strong className="text-foreground">Business Name:</strong> ZYRKO STORE</li>
                <li><strong className="text-foreground">Commercial Activity:</strong> Online retail of footwear and accessories</li>
                <li><strong className="text-foreground">Country:</strong> Spain</li>
                <li><strong className="text-foreground">Contact:</strong> WhatsApp +34 643 574 361</li>
                <li><strong className="text-foreground">Email:</strong> Available upon request via WhatsApp</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">2. Purpose of the Website</h2>
              <p className="text-muted-foreground leading-relaxed">
                This website serves as a catalog and information platform for ZYRKO STORE products. All purchases are completed through WhatsApp messaging, where our team assists customers with orders, payments, and shipping arrangements.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">3. Intellectual Property</h2>
              <p className="text-muted-foreground leading-relaxed">
                All content on this website, including but not limited to text, graphics, images, logos, icons, software, and design elements, is the property of ZYRKO STORE or its content suppliers and is protected by Spanish and international intellectual property laws. Reproduction, distribution, or modification of any content without express written permission is prohibited.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">4. Liability Limitations</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                ZYRKO STORE is not responsible for:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Technical interruptions or unavailability of the website</li>
                <li>Damages arising from the use or inability to use the website</li>
                <li>Content of external websites linked from this site</li>
                <li>Unauthorized access or alterations by third parties</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">5. User Obligations</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                By using this website, you agree to:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Provide accurate and truthful information when placing orders</li>
                <li>Use the website only for lawful purposes</li>
                <li>Not attempt to interfere with the proper functioning of the website</li>
                <li>Respect intellectual property rights</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">6. Data Protection</h2>
              <p className="text-muted-foreground leading-relaxed">
                ZYRKO STORE complies with Regulation (EU) 2016/679 (GDPR) and Spanish Organic Law 3/2018 on Personal Data Protection. For detailed information on how we collect, use, and protect your data, please refer to our Privacy Policy.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">7. Applicable Law and Jurisdiction</h2>
              <p className="text-muted-foreground leading-relaxed">
                This Legal Notice is governed by Spanish law. For any disputes, the parties submit to the courts and tribunals of the user&apos;s domicile, in accordance with applicable consumer protection regulations. Users outside the European Union may be subject to different jurisdiction rules.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">8. Alternative Dispute Resolution</h2>
              <p className="text-muted-foreground leading-relaxed">
                In accordance with Regulation (EU) No 524/2013, consumers within the European Union may submit complaints through the European Online Dispute Resolution platform at{" "}
                <a 
                  href="https://ec.europa.eu/consumers/odr" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-foreground underline underline-offset-4 hover:text-muted-foreground"
                >
                  https://ec.europa.eu/consumers/odr
                </a>
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">9. Modifications</h2>
              <p className="text-muted-foreground leading-relaxed">
                ZYRKO STORE reserves the right to modify this Legal Notice at any time. Changes will be published on this page with an updated effective date.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">10. Contact</h2>
              <p className="text-muted-foreground leading-relaxed">
                For any questions or concerns regarding this Legal Notice, please contact us via WhatsApp at +34 643 574 361 or through our Instagram account @zyrkostore.
              </p>
            </section>
          </div>

          <div className="mt-12 pt-8 border-t border-border/50">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Back to Store
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
