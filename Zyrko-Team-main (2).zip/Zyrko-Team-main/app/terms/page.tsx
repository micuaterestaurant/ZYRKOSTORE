import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Terms and Conditions | ZYRKO STORE",
  description: "Read the terms and conditions for purchasing from ZYRKO STORE. Learn about our ordering process, shipping, and policies.",
}

export default function TermsAndConditions() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50">
        <div className="container mx-auto px-4 lg:px-8 py-6">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Store
          </Link>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight mb-4">Terms and Conditions</h1>
          <p className="text-muted-foreground mb-8">Last updated: May 2026</p>

          <div className="prose prose-invert prose-gray max-w-none space-y-8">
            <section>
              <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
              <p className="text-muted-foreground leading-relaxed">
                Welcome to ZYRKO STORE. These Terms and Conditions govern your use of our website and the purchase of products from our store. By placing an order, you agree to be bound by these terms. Please read them carefully before making a purchase.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">2. Company Information</h2>
              <p className="text-muted-foreground leading-relaxed">
                ZYRKO STORE is operated from Spain. For any inquiries, you can contact us via WhatsApp at +34 643 574 361 or through our social media channels.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">3. Products and Pricing</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                All products displayed on our website are subject to availability. Prices are displayed in Euros (€) and include applicable taxes for EU customers. We reserve the right to modify prices at any time without prior notice. Prices at the time of order confirmation will be honored.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Product images are for illustrative purposes. While we strive for accuracy, slight variations in color may occur due to screen settings.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">4. Ordering Process</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Orders are placed via WhatsApp. The process is as follows:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Select your desired product and size on our website</li>
                <li>Click the WhatsApp order button to initiate contact</li>
                <li>Confirm your order details with our team</li>
                <li>Provide shipping information</li>
                <li>Complete payment as instructed</li>
                <li>Receive order confirmation and tracking information</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">5. Payment</h2>
              <p className="text-muted-foreground leading-relaxed">
                We accept various payment methods as communicated during the WhatsApp ordering process. Payment must be completed before order processing. All transactions are secure and your payment information is protected.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">6. Shipping</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                We ship worldwide to over 100 countries. Estimated delivery times are:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Spain: 2-4 business days</li>
                <li>European Union: 5-10 business days</li>
                <li>United States: 7-14 business days</li>
                <li>Rest of World: 10-20 business days</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Delivery times are estimates and may vary due to customs processing or local delivery conditions. Tracking information is provided for all orders.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">7. Returns and Refunds</h2>
              <p className="text-muted-foreground leading-relaxed">
                Please refer to our separate Refund Policy for detailed information about returns, exchanges, and refunds.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">8. Intellectual Property</h2>
              <p className="text-muted-foreground leading-relaxed">
                All content on this website, including text, graphics, logos, and images, is the property of ZYRKO STORE and is protected by intellectual property laws. You may not reproduce, distribute, or use any content without our prior written consent.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">9. Limitation of Liability</h2>
              <p className="text-muted-foreground leading-relaxed">
                ZYRKO STORE shall not be liable for any indirect, incidental, or consequential damages arising from the use of our website or products. Our liability is limited to the purchase price of the products ordered.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">10. Governing Law</h2>
              <p className="text-muted-foreground leading-relaxed">
                These Terms and Conditions are governed by Spanish law. Any disputes shall be subject to the exclusive jurisdiction of the Spanish courts, without prejudice to mandatory consumer protection laws in your country of residence.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">11. Changes to Terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                We reserve the right to modify these Terms and Conditions at any time. Changes will be effective immediately upon posting on this page. Your continued use of our services constitutes acceptance of the modified terms.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">12. Contact</h2>
              <p className="text-muted-foreground leading-relaxed">
                For any questions regarding these Terms and Conditions, please contact us via WhatsApp at +34 643 574 361 or through Instagram @zyrkostore.
              </p>
            </section>
          </div>

          <div className="mt-12 pt-8 border-t border-border/50">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Back to Store
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
