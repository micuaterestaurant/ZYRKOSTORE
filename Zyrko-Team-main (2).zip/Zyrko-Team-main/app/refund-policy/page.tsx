import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Refund Policy | ZYRKO STORE",
  description: "ZYRKO STORE refund and return policy. 14-day returns for unworn items. Learn about our exchange and refund process.",
}

export default function RefundPolicy() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50">
        <div className="container mx-auto px-4 lg:px-8 py-6">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Store
          </Link>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight mb-4">Refund Policy</h1>
          <p className="text-muted-foreground mb-8">Last updated: May 2026</p>

          <div className="prose prose-invert prose-gray max-w-none space-y-8">
            <section>
              <h2 className="text-xl font-semibold mb-4">1. Return Window</h2>
              <p className="text-muted-foreground leading-relaxed">
                You have 14 calendar days from the date of delivery to request a return. This is in accordance with EU consumer protection regulations. To initiate a return, please contact us via WhatsApp within this period.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">2. Return Conditions</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                To be eligible for a return, items must meet the following conditions:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Unworn and in original condition</li>
                <li>In original packaging with all tags attached</li>
                <li>No signs of wear, damage, or alterations</li>
                <li>Clean and free from odors</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Items that do not meet these conditions may be rejected or subject to a restocking fee.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">3. Return Process</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                To return an item, follow these steps:
              </p>
              <ul className="list-decimal pl-6 text-muted-foreground space-y-2">
                <li>Contact us via WhatsApp at +34 643 574 361</li>
                <li>Provide your order details and reason for return</li>
                <li>Receive return authorization and shipping instructions</li>
                <li>Ship the item back using a trackable shipping method</li>
                <li>Once received and inspected, we will process your refund</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">4. Return Shipping Costs</h2>
              <p className="text-muted-foreground leading-relaxed">
                Return shipping costs are the responsibility of the customer, unless the return is due to our error (wrong item sent, defective product, etc.). We recommend using a trackable shipping service as we cannot be responsible for items lost in return transit.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">5. Refund Processing</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Once we receive and inspect your return, we will notify you via WhatsApp. If approved:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Refunds are processed within 5-7 business days</li>
                <li>Refunds are issued to the original payment method</li>
                <li>Original shipping costs are non-refundable (unless due to our error)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">6. Exchanges</h2>
              <p className="text-muted-foreground leading-relaxed">
                We offer exchanges for different sizes subject to availability. To request an exchange, contact us via WhatsApp. If the desired size is not available, we will process a refund instead.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">7. Defective or Wrong Items</h2>
              <p className="text-muted-foreground leading-relaxed">
                If you receive a defective item or an item different from what you ordered, please contact us immediately via WhatsApp with photos of the issue. We will arrange for a return at our expense and send the correct item or issue a full refund.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">8. Non-Returnable Items</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                The following items cannot be returned:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Items marked as final sale</li>
                <li>Items that have been worn or used</li>
                <li>Items without original tags or packaging</li>
                <li>Items returned after the 14-day window</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">9. Contact Us</h2>
              <p className="text-muted-foreground leading-relaxed">
                For any questions about returns or refunds, please contact us via WhatsApp at +34 643 574 361. Our support team is available Monday to Friday, 9AM-6PM CET.
              </p>
            </section>
          </div>

          <div className="mt-12 pt-8 border-t border-border/50">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Back to Store
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
