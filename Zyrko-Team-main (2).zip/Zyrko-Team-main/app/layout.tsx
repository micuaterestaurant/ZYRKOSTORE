import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'

const geistSans = Geist({ 
  subsets: ['latin'],
  variable: '--font-geist-sans',
})

const geistMono = Geist_Mono({ 
  subsets: ['latin'],
  variable: '--font-geist-mono',
})

export const metadata: Metadata = {
  title: 'ZYRKO STORE | Premium Sneakers • Worldwide Shipping',
  description: 'Discover exclusive premium sneakers at ZYRKO STORE. Limited drops, worldwide shipping, and the finest streetwear footwear. Shop the latest DROP 001 collection now.',
  keywords: ['sneakers', 'premium sneakers', 'streetwear', 'limited edition', 'worldwide shipping', 'ZYRKO', 'designer sneakers', 'luxury footwear'],
  authors: [{ name: 'ZYRKO STORE' }],
  creator: 'ZYRKO STORE',
  publisher: 'ZYRKO STORE',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://zyrko.store',
    siteName: 'ZYRKO STORE',
    title: 'ZYRKO STORE | Premium Sneakers • Worldwide Shipping',
    description: 'Discover exclusive premium sneakers at ZYRKO STORE. Limited drops, worldwide shipping, and the finest streetwear footwear.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ZYRKO STORE | Premium Sneakers',
    description: 'Discover exclusive premium sneakers at ZYRKO STORE. Limited drops, worldwide shipping.',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#0a0a0a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  )
}
