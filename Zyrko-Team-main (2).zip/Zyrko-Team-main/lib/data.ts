export const products = [
  {
    id: 1,
    name: "Viral Nike Mind 001",
    price: "64,99€",
    tag: "DROP 001",
    image: "/nike-mind.jpg",
    description: "Premium comfort slides with futuristic design.",
    sizes: ["38", "39", "40", "41", "42", "43"]
  }
]

export const reviews = [
  {
    id: 1,
    name: "Alex M.",
    text: "Increíble calidad, muy cómodas.",
    rating: 5,
    location: "Spain",
    product: "Nike Mind 001",
    verified: true
  }
]

export const faqs = [
  {
    id: 1,
    question: "¿Cuánto tarda el envío?",
    answer: "24-72h dependiendo del país."
  }
]
